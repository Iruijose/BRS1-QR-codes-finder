# BRS1 Manual Staking QR Finder

A simple static search page for finding BRS1 manual staking filter QR codes by sort name.

## How to publish on GitHub Pages

1. Go to https://github.com/new and create a new repository (e.g. `brs1-qr-finder`). Public is required for free GitHub Pages.
2. On your computer, unzip/open this folder — it contains:
   - `index.html` (the site)
   - `images/` (all 52 QR code images)
3. On the new repo's GitHub page, click **"uploading an existing file"**, drag in `index.html` and the whole `images` folder, then commit.
4. Go to the repo's **Settings → Pages**.
5. Under "Build and deployment", set Source = **Deploy from a branch**, Branch = **main**, folder = **/ (root)**. Save.
6. Wait ~1 minute, then your site will be live at:
   `https://<your-username>.github.io/brs1-qr-finder/`

Share that link with anyone — it works even when your laptop is off.

## Updating later

To add or change QR codes, edit the `ALL_DATA` array near the top of the `<script>` section in `index.html` (or add new image files to `images/` and add a matching entry), then re-upload/commit the changed files on GitHub.
